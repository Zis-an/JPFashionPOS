<?php $__env->startSection('title', 'Raw Material Purchases'); ?>
<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1>Raw Material Purchases</h1>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rawMaterialPurchases.create')): ?>
                <a href="<?php echo e(route('admin.raw-material-purchases.create')); ?>" class="btn btn-primary mt-2">Add new</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rawMaterialPurchases.trashed')): ?>
                <a href="<?php echo e(route('admin.raw-material-purchases.trashed')); ?>" class="btn btn-danger mt-2">Trash List</a>
            <?php endif; ?>
        </div>
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                <li class="breadcrumb-item active">Purchases</li>
            </ol>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rawMaterialPurchases.list')): ?>
                <div class="card">
                    <div class="card-body table-responsive">
                        <table id="purchasesList" class="table dataTable table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Supplier</th>
                                <th>Warehouse</th>
                                <th>Account</th>
                                <th>Total Cost</th>
                                <th>Purchase Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($purchase->supplier->name ?? ''); ?></td>
                                    <td><?php echo e($purchase->warehouse->name ?? ''); ?></td>
                                    <td><?php echo e($purchase->account->name ?? ''); ?></td>
                                    <td><?php echo e($purchase->total_cost ?? ''); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($purchase->purchase_date)->format('Y-m-d') ?? ''); ?></td>
                                    <td><?php echo e(ucfirst($purchase->status ?? '')); ?></td>
                                    <td class="text-center">
                                        <form action="<?php echo e(route('admin.raw-material-purchases.destroy', $purchase->id)); ?>" method="POST">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rawMaterialPurchases.updateStatus')): ?>
                                                <?php if($purchase->status == 'pending'): ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rawMaterialPurchases.view')): ?>
                                                        <a href="<?php echo e(route('admin.raw-material-purchases.show',['raw_material_purchase'=>$purchase->id])); ?>"
                                                           class="btn btn-info px-1 py-0 btn-sm">
                                                            <i class="fa fa-eye"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rawMaterialPurchases.update')): ?>
                                                        <a href="<?php echo e(route('admin.raw-material-purchases.edit',['raw_material_purchase'=>$purchase->id])); ?>"
                                                           class="btn btn-warning px-1 py-0 btn-sm">
                                                            <i class="fa fa-pen"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rawMaterialPurchases.delete')): ?>
                                                        <button onclick="isDelete(this)" class="btn btn-danger btn-sm px-1 py-0">
                                                            <i class="fa fa-trash"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                    <a href="<?php echo e(route('admin.raw-material-purchases.updateStatus', ['raw_material_purchase' => $purchase->id, 'status' => 'approved'])); ?>"
                                                       class="btn btn-success btn-sm px-1 py-0">
                                                        <i class="fas fa-check"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('admin.raw-material-purchases.updateStatus', ['raw_material_purchase' => $purchase->id, 'status' => 'rejected'])); ?>"
                                                       class="btn btn-danger btn-sm px-1 py-0">
                                                        <i class="fas fa-times"></i>
                                                    </a>
                                                <?php elseif($purchase->status == 'rejected'): ?>
                                                    <a href="<?php echo e(route('admin.raw-material-purchases.updateStatus', ['raw_material_purchase' => $purchase->id, 'status' => 'pending'])); ?>"
                                                       class="btn btn-primary btn-sm px-1 py-0">
                                                        <i class="fas fa-arrow-alt-circle-left"></i>
                                                    </a>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rawMaterialPurchases.view')): ?>
                                                        <a href="<?php echo e(route('admin.raw-material-purchases.show',['raw_material_purchase'=>$purchase->id])); ?>"
                                                           class="btn btn-info px-1 py-0 btn-sm">
                                                            <i class="fa fa-eye"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <?php elseif($purchase->status == 'approved'): ?>
                                                        <a href="<?php echo e(route('admin.raw-material-purchases.updateStatus', ['raw_material_purchase' => $purchase->id, 'status' => 'pending'])); ?>"
                                                           class="btn btn-primary btn-sm px-1 py-0">
                                                            <i class="fas fa-arrow-alt-circle-left"></i>
                                                        </a>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rawMaterialPurchases.view')): ?>
                                                        <a href="<?php echo e(route('admin.raw-material-purchases.show',['raw_material_purchase'=>$purchase->id])); ?>"
                                                           class="btn btn-info px-1 py-0 btn-sm">
                                                            <i class="fa fa-eye"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                   <?php endif; ?>
                                                    <a target="_blank"
                                                       rel="noopener noreferrer"
                                                       onclick="openSinglePrivateWindow(this.href); return false;"
                                                       href="<?php echo e(route('admin.raw-material-purchases.print', ['raw_material_purchase'=>$purchase->id])); ?>" class="btn btn-warning btn-sm px-1 py-0">
                                                        <i class="fas fa-print"></i>
                                                    </a>
                                            <?php endif; ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <th>Supplier</th>
                                <th>Warehouse</th>
                                <th>Account</th>
                                <th>Total Cost</th>
                                <th>Purchase Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <strong>Developed by <a href="https://www.techyfo.com">Techyfo</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>version</b> <?php echo e(env('DEV_VERSION')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.datatablesPlugins', true); ?>
<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        let privateWindow = null;

        function openSinglePrivateWindow(url) {
            // If a private window is already open, focus on it instead of opening a new one
            if (!privateWindow || privateWindow.closed) {
                privateWindow = window.open(url, '_blank', 'noopener,noreferrer,width=800,height=600');
            } else {
                privateWindow.focus();
            }
        }
    </script>
    <script>
        function isDelete(button) {
            event.preventDefault();
            var row = $(button).closest("tr");
            var form = $(button).closest("form");
            Swal.fire({
                title: <?php echo json_encode(__('Delete RawMaterialPurchase'), 15, 512) ?>,
                text: <?php echo json_encode(__('Are you sure you want to delete this?'), 15, 512) ?>,
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: <?php echo json_encode(__('Delete'), 15, 512) ?>,
                cancelButtonText: <?php echo json_encode(__('Cancel'), 15, 512) ?>,
            }).then((result) => {
                if (result.value) {
                    form.submit();
                }
            });
        }

        $(document).ready(function() {
            $("#purchasesList").DataTable({
                dom: 'Bfrtip',
                responsive: true,
                lengthChange: false,
                autoWidth: false,
                searching: true,
                ordering: true,
                info: true,
                paging: true,
                buttons: [
                    {
                        extend: 'copy',
                        text: 'Copy',
                    },
                    {
                        extend: 'csv',
                        text: 'Export CSV',
                    },
                    {
                        extend: 'excel',
                        text: 'Export Excel',
                    },
                    {
                        extend: 'pdf',
                        text: 'Export PDF',
                    },
                    {
                        extend: 'print',
                        text: 'Print',
                    },
                    {
                        extend: 'colvis',
                        text: 'Colvis',
                    }
                ],
                pagingType: 'full_numbers',
                pageLength: 10,
                lengthMenu: [10, 25, 50, 100],
                language: {
                    paginate: {
                        first: "<?php echo e(__('First')); ?>",
                        previous: "<?php echo e(__('Previous')); ?>",
                        next: "<?php echo e(__('Next')); ?>",
                        last: "<?php echo e(__('Last')); ?>",
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Zisan\Projects\JPFashionPOS\JPFashionPos\resources\views/admin/raw-material-purchases/index.blade.php ENDPATH**/ ?>