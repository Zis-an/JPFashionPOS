<?php $__env->startSection('title', 'Customer Payments'); ?>
<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1>Customer Payments</h1>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customerPayments.list')): ?>
                <a href="<?php echo e(route('admin.customer-payments.index')); ?>" class="btn btn-primary mt-2">Go Back</a>
            <?php endif; ?>

        </div>
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                <li class="breadcrumb-item active">Customer Payments</li>
            </ol>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customerPayments.list')): ?>
                <div class="card">
                    <div class="card-body table-responsive">
                        <table id="adminsList" class="table dataTable table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Customer Name</th>
                                <th>Account Name</th>
                                <th>Amount</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($payment->customer->name); ?></td>
                                    <td><?php echo e($payment->account->name); ?></td>
                                    <td><?php echo e($payment->amount); ?></td>
                                    <td class="text-center">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customerPayments.restore')): ?>
                                            <a href="<?php echo e(route('admin.customer-payments.restore',['customer_payment'=>$payment->id])); ?>" class="btn btn-success btn-sm px-1 py-0">
                                                <i class="fa fa-arrow-left"></i>
                                            </a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customerPayments.force_delete')): ?>
                                            <a href="<?php echo e(route('admin.customer-payments.force_delete',['customer_payment'=>$payment->id])); ?>" class="btn btn-danger btn-sm px-1 py-0">
                                                <i class="fa fa-trash"></i>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                            <tfoot>
                            <tr>
                                <th>Customer Name</th>
                                <th>Account Name</th>
                                <th>Amount</th>
                                <th>Action</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <strong>Developed by <a href="https://www.techyfo.com">Techyfo</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>version</b> <?php echo e(env('DEV_VERSION')); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('plugins.datatablesPlugins', true); ?>
<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        function isDelete(button) {
            event.preventDefault();
            var row = $(button).closest("tr");
            var form = $(button).closest("form");
            Swal.fire({
                title: <?php echo json_encode(__('Delete Payment Permanently'), 15, 512) ?>,
                text: <?php echo json_encode(__('Are you sure you want to delete this?'), 15, 512) ?>,
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: <?php echo json_encode(__('Delete'), 15, 512) ?>,
                cancelButtonText: <?php echo json_encode(__('Cancel'), 15, 512) ?>,
            }).then((result) => {
                console.log(result)
                if (result.value) {
                    // Trigger the form submission
                    form.submit();
                }
            });
        }

        $(document).ready(function() {
            $("#adminsList").DataTable({
                dom: 'Bfrtip',
                responsive: true,
                lengthChange: false,
                autoWidth: false,
                searching: true,
                ordering: true,
                info: true,
                paging: true,
                buttons: [
                    {
                        extend: 'copy',
                        text: 'Copy',
                    },
                    {
                        extend: 'csv',
                        text: 'Export CSV',
                    },
                    {
                        extend: 'excel',
                        text: 'Export Excel',
                    },
                    {
                        extend: 'pdf',
                        text: 'Export PDF',
                    },
                    {
                        extend: 'print',
                        text: 'Print',
                    },
                    {
                        extend: 'colvis',
                        text: 'Colvis',
                    }
                ],
                pagingType: 'full_numbers',
                pageLength: 10,
                lengthMenu: [10, 25, 50, 100],
                language: {
                    paginate: {
                        first: "First",
                        previous: "Previous",
                        next: "Next",
                        last: "Last",
                    }
                }
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Zisan\Projects\JPFashionPOS\JPFashionPos\resources\views/admin/customerPayments/trashed.blade.php ENDPATH**/ ?>