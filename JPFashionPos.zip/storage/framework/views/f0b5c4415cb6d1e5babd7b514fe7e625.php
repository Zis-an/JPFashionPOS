<?php $__env->startSection('title', 'View Production'); ?>
<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1>View Production Information - <?php echo e($production->productionHouse->name); ?></h1>
        </div>
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.productions.index')); ?>">Productions</a></li>
                <li class="breadcrumb-item active">View Production</li>
            </ol>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                        <?php if(count($errors) > 0): ?>
                            <div class = "alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>



                        <table class="table table-bordered w-100 text-left mb-3">
                            <tr>
                                <th style="width: 30%;">Production House</th>
                                <td><?php echo e($production->productionHouse->name); ?></td>
                            </tr>
                            <tr>
                                <th style="width: 30%;">Showroom</th>
                                <td><?php echo e($production->showroom->name); ?></td>
                            </tr>
                            <tr>
                                <th style="width: 30%;">Account</th>
                                <td><?php echo e($production->account->name); ?></td>
                            </tr>
                            <tr>
                                <th style="width: 30%;">Production Date</th>
                                <td><?php echo e($production->production_date); ?></td>
                            </tr>
                            <tr>
                                <th style="width: 30%;">Cost Details</th>
                                <td><pre><?php echo e($production->cost_details); ?></pre></td>
                            </tr>
                            <tr>
                                <th style="width: 30%;">Total Cost</th>
                                <td><?php echo e($production->total_cost); ?></td>
                            </tr>
                            <tr>
                                <th style="width: 30%;">Total Raw Material Cost</th>
                                <td><?php echo e($production->total_raw_material_cost); ?></td>
                            </tr>
                            <tr>
                                <th style="width: 30%;">Total Product Cost</th>
                                <td><?php echo e($production->total_product_cost); ?></td>
                            </tr>
                            <tr>
                                <th style="width: 30%;">Total Amount</th>
                                <td><?php echo e($production->amount); ?></td>
                            </tr>
                            <tr>
                                <th style="width: 30%;">Status</th>
                                <td class="text-capitalize"><?php echo e($production->status); ?></td>
                            </tr>
                        </table>
                        <fieldset class="mt-4">
                            <legend>Raw Materials</legend>
                            <table class="table table-bordered">
                                <thead>
                                <tr>
                                    <th>Material Name</th>
                                    <th>Brand</th>
                                    <th>Size</th>
                                    <th>Color</th>
                                    <th>Warehouse</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $production->rawMaterials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td><?php echo e(optional($material->rawMaterial)->name); ?></td>
                                        <td><?php echo e(optional($material->brand)->name); ?></td>
                                        <td><?php echo e(optional($material->size)->name); ?></td>
                                        <td><?php echo e(optional($material->color)->color_name); ?></td>
                                        <td><?php echo e(optional($material->warehouse)->name); ?></td>
                                        <td><?php echo e($material->price); ?></td>
                                        <td><?php echo e($material->quantity); ?></td>
                                        <td><?php echo e($material->total_price); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </fieldset>
                        <fieldset class="mt-4">
                            <legend>Products</legend>
                            <table class="table table-bordered">
                                <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Brand</th>
                                    <th>Size</th>
                                    <th>Color</th>
                                    <th>Cost per Qty</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $production->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productionProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(optional($productionProduct->product)->name); ?></td>
                                        <td><?php echo e(optional($productionProduct->brand)->name); ?></td>
                                        <td><?php echo e(optional($productionProduct->size)->name); ?></td>
                                        <td><?php echo e(optional($productionProduct->color)->color_name); ?></td>
                                        <td><?php echo e($productionProduct->per_pc_cost); ?></td>
                                        <td><?php echo e($productionProduct->quantity); ?></td>
                                        <td><?php echo e($productionProduct->sub_total); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </fieldset>
















                        <form action="<?php echo e(route('admin.productions.destroy', $production->id)); ?>" method="POST">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <a href="<?php echo e(route('admin.productions.index')); ?>" class="btn btn-success" >Go Back</a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('productions.update')): ?>
                                <a href="<?php echo e(route('admin.productions.edit',['production'=>$production->id])); ?>" class="btn btn-warning ">
                                    <i class="fa fa-pen"></i> Edit
                                </a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('productions.delete')): ?>
                                <button onclick="isDelete(this)" class="btn btn-danger"><i class="fa fa-trash"></i> Delete</button>
                            <?php endif; ?>
                        </form>

                            <div class="row mt-4 mb-4">
                                <div class="col-md-12">
                                    <h5>Activity Log</h5>
                                    <?php if($activities->isEmpty()): ?>
                                        <p>No activities found for this Production.</p>
                                    <?php else: ?>
                                        <div class="table-responsive">
                                            <table id="activityTable" class="table order-table table-bordered w-100">
                                                <thead>
                                                <tr>
                                                    <th>SL.</th>
                                                    <th>Action</th>
                                                    <th>Admin</th>
                                                    <th>IP Address</th>
                                                    <th>Date</th>
                                                    <th>Details</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $activityData = json_decode($activity->data, true);
                                                        $adminName = $activity->admin->name ?? 'Unknown';
                                                    ?>
                                                    <tr>
                                                        <td><?php echo e($key + 1); ?></td>
                                                        <td class="text-capitalize"><?php echo e($activity->action); ?></td>
                                                        <td><?php echo e($adminName); ?></td>
                                                        <td><?php echo e($activity->ip_address); ?></td>
                                                        <td><?php echo e($activity->created_at->format('d M Y H:i A')); ?></td>
                                                        <td>
                                                            <a class="badge badge-info badge-sm " style="cursor: pointer" data-toggle="modal"
                                                               data-target="#activityModal-<?php echo e($activity->id); ?>">
                                                                <i class="fa fa-eye"></i> Details
                                                            </a>

                                                            <!-- Modal -->
                                                            <div class="modal fade" id="activityModal-<?php echo e($activity->id); ?>" tabindex="-1" role="dialog" aria-labelledby="activityModalLabel-<?php echo e($activity->id); ?>" aria-hidden="true">
                                                                <div class="modal-dialog" role="document">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title" id="activityModalLabel-<?php echo e($activity->id); ?>">Activity Details</h5>
                                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                                <span aria-hidden="true">&times;</span>
                                                                            </button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <pre><?php echo e(json_encode($activityData, JSON_PRETTY_PRINT)); ?></pre>
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <strong>Developed by <a href="https://www.techyfo.com">Techyfo</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>version</b> <?php echo e(env('DEV_VERSION')); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('plugins.toastr',true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>
<?php $__env->startSection('plugins.datatablesPlugins', true); ?>
<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        function isDelete(button) {
            event.preventDefault();
            var row = $(button).closest("tr");
            var form = $(button).closest("form");
            Swal.fire({
                title: <?php echo json_encode(__('Delete Production Information'), 15, 512) ?>,
                text: <?php echo json_encode(__('Are you sure you want to delete this?'), 15, 512) ?>,
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: <?php echo json_encode(__('Delete'), 15, 512) ?>,
                cancelButtonText: <?php echo json_encode(__('Cancel'), 15, 512) ?>,
            }).then((result) => {
                console.log(result)
                if (result.value) {
                    // Trigger the form submission
                    form.submit();
                }
            });
        }

        function checkSinglePermission(idName, className,inGroupCount,total,groupCount) {
            if($('.'+className+' input:checked').length === inGroupCount){
                $('#'+idName).prop('checked',true);
            }else {
                $('#'+idName).prop('checked',false);
            }
            if($('.permissions input:checked').length === total+groupCount){
                $('#select_all').prop('checked',true);
            }else {
                $('#select_all').prop('checked',false);
            }
        }

        function checkPermissionByGroup(idName, className,total,groupCount) {
            if($('#'+idName).is(':checked')){
                $('.'+className+' input').prop('checked',true);
            }else {
                $('.'+className+' input').prop('checked',false);
            }
            if($('.permissions input:checked').length === total+groupCount){
                $('#select_all').prop('checked',true);
            }else {
                $('#select_all').prop('checked',false);
            }
        }

        $('#select_all').click(function(event) {
            if(this.checked) {
                // Iterate each checkbox
                $(':checkbox').each(function() {
                    this.checked = true;
                });
            } else {
                $(':checkbox').each(function() {
                    this.checked = false;
                });
            }
        });
    </script>

    <!-- Initialize DataTable -->
    <script>
        $(document).ready(function() {

            $("#activityTable").DataTable({
                dom: 'Bfrtip',
                responsive: true,
                lengthChange: false,
                autoWidth: false,
                searching: true, // Disable the global search box
                ordering: true,
                info: true,
                paging: true,
                buttons: [
                    {
                        text: "Created",
                        action: function(e, dt, node, config){
                            dt.column(1).search("created").draw();
                        }
                    },
                    {
                        text: "Updated",
                        action: function(e, dt, node, config){
                            dt.column(1).search("updated").draw();
                        }
                    },
                    {
                        text: "Deleted",
                        action: function(e, dt, node, config){
                            dt.column(1).search("deleted").draw();
                        }
                    },
                    { extend: 'copy', text: 'Copy' },
                    { extend: 'csv', text: 'Export CSV' },
                    { extend: 'excel', text: 'Export Excel' },
                    { extend: 'pdf', text: 'Export PDF' },
                    { extend: 'print', text: 'Print' },
                    { extend: 'colvis', text: 'Colvis' }
                ],
                pagingType: 'full_numbers',
                pageLength: 10,
                lengthMenu: [10, 25, 50, 100],
                language: {
                    paginate: {
                        first: "<?php echo e(__('First')); ?>",
                        previous: "<?php echo e(__('Previous')); ?>",
                        next: "<?php echo e(__('Next')); ?>",
                        last: "<?php echo e(__('Last')); ?>",
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Zisan\Projects\JPFashionPOS\JPFashionPos\resources\views/admin/productions/show.blade.php ENDPATH**/ ?>