<?php $__env->startSection('title', 'Global Settings'); ?>
<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1>Global Settings</h1>
        </div>
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                <li class="breadcrumb-item active">Global Settings</li>
            </ol>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('admin.update_global_setting')); ?>" method="POST" enctype="multipart/form-data" id="code_setting">
                        <?php echo csrf_field(); ?>
                        <?php if(count($errors) > 0): ?>
                            <div class = "alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-lg-3 col-md-4 col-sm-6">
                                <div class="form-group">
                                    <label for="site_name">Site Name</label>
                                    <input id="site_name" value="<?php echo e(getSetting('site_name')); ?>"  name="site_name" class="form-control" placeholder="Site Name">
                                </div>
                            </div>








                        </div>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('global_setting_manage')): ?>
                            <button class="btn btn-success" type="submit">Update</button>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <strong><?php echo e(__('global.developed_by')); ?> <a href="https://soft-itbd.com"><?php echo e(__('global.soft_itbd')); ?></a>.</strong>
    <?php echo e(__('global.all_rights_reserved')); ?>.
    <div class="float-right d-none d-sm-inline-block">
        <b><?php echo e(__('global.version')); ?></b> <?php echo e(env('DEV_VERSION')); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            toastr.now();
        });

    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const imageForm = document.getElementById('site_setting');

            const site_faviconImage = document.getElementById('selected-site_favicon');
            const site_logoImage = document.getElementById('selected-site_logo');

            imageForm.addEventListener('change', function () {
                const site_favicon = this.querySelector('input[name="site_favicon"]').files[0];
                const site_logo = this.querySelector('input[name="site_logo"]').files[0];
                if (site_favicon) {
                    site_faviconImage.src = URL.createObjectURL(site_favicon);
                }
                if (site_logo) {
                    site_logoImage.src = URL.createObjectURL(site_logo);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Zisan\Projects\JPFashionPOS\JPFashionPos\resources\views/admin/settings/global_setting.blade.php ENDPATH**/ ?>