<?php $__env->startSection('title', 'View Customer Payment'); ?>
<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1>View Customer Payment - <?php echo e($payment->customer->name); ?></h1>
        </div>
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.customer-payments.index')); ?>">Customer Payments</a></li>
                <li class="breadcrumb-item active">View Customer Payment</li>
            </ol>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                        <?php if(count($errors) > 0): ?>
                            <div class = "alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                            <table class="table table-bordered w-100 text-left">
                                <tr>
                                    <th style="width: 30%;">Customer</th>
                                    <td><?php echo e($payment->customer->name ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th style="width: 30%;">Account</th>
                                    <td><?php echo e($payment->account->name ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th style="width: 30%;">Amount</th>
                                    <td><?php echo e($payment->amount ?? ''); ?> BDT</td>
                                </tr>
                                <tr>
                                    <th style="width: 30%;">Details</th>
                                    <td><?php echo e(strip_tags($payment->details) ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th style="width: 30%;">Date</th>
                                    <td><?php echo e($payment->date ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th style="width: 30%;">Received By</th>
                                    <td><?php echo e(strip_tags($payment->received_by) ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th style="width: 30%;">Status</th>
                                    <td><?php echo e(ucfirst($payment->status)); ?></td>
                                </tr>
                            </table>
                            <div class="my-3">
                                <legend>Customer Payment's Photos</legend>
                            </div>
                            <div id="image-preview-container" class="form-group mb-2 d-flex flex-wrap">
                                <?php if($payment->image): ?>
                                    <img src="<?php echo e(asset($payment->image)); ?>" alt="Payment Photo" class="selected-image">
                                <?php else: ?>
                                    <p>No photos available.</p>
                                <?php endif; ?>
                            </div>

                        <form action="<?php echo e(route('admin.customer-payments.destroy', $payment->id)); ?>" method="POST">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <a href="<?php echo e(route('admin.customer-payments.index')); ?>" class="btn btn-success" >Go Back</a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customerPayments.update')): ?>
                                <a href="<?php echo e(route('admin.customer-payments.edit',['customer_payment'=>$payment->id])); ?>" class="btn btn-warning ">
                                    <i class="fa fa-pen"></i> Edit
                                </a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customerPayments.delete')): ?>
                                <button onclick="isDelete(this)" class="btn btn-danger"><i class="fa fa-trash"></i> Delete</button>
                            <?php endif; ?>
                        </form>

                            <div class="row mt-4 mb-4">
                                <div class="col-md-12">
                                    <h5>Activity Log</h5>
                                    <?php if($activities->isEmpty()): ?>
                                        <p>No activities found for this payment.</p>
                                    <?php else: ?>
                                        <div class="table-responsive">
                                            <table id="activityTable" class="table order-table table-bordered w-100">
                                                <thead>
                                                <tr>
                                                    <th>SL.</th>
                                                    <th>Action</th>
                                                    <th>Admin</th>
                                                    <th>IP Address</th>
                                                    <th>Date</th>
                                                    <th>Details</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $activityData = json_decode($activity->data, true);
                                                        $adminName = $activity->admin->name ?? 'Unknown';
                                                    ?>
                                                    <tr>
                                                        <td><?php echo e($key + 1); ?></td>
                                                        <td class="text-capitalize"><?php echo e($activity->action); ?></td>
                                                        <td><?php echo e($adminName); ?></td>
                                                        <td><?php echo e($activity->ip_address); ?></td>
                                                        <td><?php echo e($activity->created_at->format('d M Y H:i A')); ?></td>
                                                        <td>
                                                            <a class="badge badge-info badge-sm " style="cursor: pointer" data-toggle="modal"
                                                               data-target="#activityModal-<?php echo e($activity->id); ?>">
                                                                <i class="fa fa-eye"></i> Details
                                                            </a>

                                                            <!-- Modal -->
                                                            <div class="modal fade" id="activityModal-<?php echo e($activity->id); ?>" tabindex="-1" role="dialog" aria-labelledby="activityModalLabel-<?php echo e($activity->id); ?>" aria-hidden="true">
                                                                <div class="modal-dialog" role="document">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title" id="activityModalLabel-<?php echo e($activity->id); ?>">Activity Details</h5>
                                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                                <span aria-hidden="true">&times;</span>
                                                                            </button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <pre><?php echo e(json_encode($activityData, JSON_PRETTY_PRINT)); ?></pre>
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <strong>Developed by <a href="https://www.techyfo.com">Techyfo</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>version</b> <?php echo e(env('DEV_VERSION')); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('plugins.toastr',true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>
<?php $__env->startSection('plugins.datatablesPlugins', true); ?>
<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .selected-image {
            width: 150px; /* Moderate width */
            height: 100px; /* Rectangular shape */
            border: 2px solid #ddd;
            border-radius: 8px;
            object-fit: cover;
            display: block;
            margin-right: 10px; /* Space between images */
            margin-bottom: 10px; /* Space between rows if needed */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: opacity 0.3s ease;
        }

        #image-preview-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px; /* Space between images */
        }

        @media (max-width: 767px) {
            .selected-image {
                width: 120px; /* Adjust for smaller screens */
                height: 80px; /* Adjust for smaller screens */
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        function isDelete(button) {
            event.preventDefault();
            var row = $(button).closest("tr");
            var form = $(button).closest("form");
            Swal.fire({
                title: <?php echo json_encode(__('Delete Payment'), 15, 512) ?>,
                text: <?php echo json_encode(__('Are you sure you want to delete this?'), 15, 512) ?>,
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: <?php echo json_encode(__('Delete'), 15, 512) ?>,
                cancelButtonText: <?php echo json_encode(__('Cancel'), 15, 512) ?>,
            }).then((result) => {
                console.log(result)
                if (result.value) {
                    // Trigger the form submission
                    form.submit();
                }
            });
        }

        function checkSinglePermission(idName, className,inGroupCount,total,groupCount) {
            if($('.'+className+' input:checked').length === inGroupCount){
                $('#'+idName).prop('checked',true);
            }else {
                $('#'+idName).prop('checked',false);
            }
            if($('.permissions input:checked').length === total+groupCount){
                $('#select_all').prop('checked',true);
            }else {
                $('#select_all').prop('checked',false);
            }
        }

        function checkPermissionByGroup(idName, className,total,groupCount) {
            if($('#'+idName).is(':checked')){
                $('.'+className+' input').prop('checked',true);
            }else {
                $('.'+className+' input').prop('checked',false);
            }
            if($('.permissions input:checked').length === total+groupCount){
                $('#select_all').prop('checked',true);
            }else {
                $('#select_all').prop('checked',false);
            }
        }

        $('#select_all').click(function(event) {
            if(this.checked) {
                // Iterate each checkbox
                $(':checkbox').each(function() {
                    this.checked = true;
                });
            } else {
                $(':checkbox').each(function() {
                    this.checked = false;
                });
            }
        });
    </script>

    <!-- Initialize DataTable -->
    <script>
        $(document).ready(function() {

            $("#activityTable").DataTable({
                dom: 'Bfrtip',
                responsive: true,
                lengthChange: false,
                autoWidth: false,
                searching: true, // Disable the global search box
                ordering: true,
                info: true,
                paging: true,
                buttons: [
                    {
                        text: "Created",
                        action: function(e, dt, node, config){
                            dt.column(1).search("created").draw();
                        }
                    },
                    {
                        text: "Updated",
                        action: function(e, dt, node, config){
                            dt.column(1).search("updated").draw();
                        }
                    },
                    {
                        text: "Deleted",
                        action: function(e, dt, node, config){
                            dt.column(1).search("deleted").draw();
                        }
                    },
                    { extend: 'copy', text: 'Copy' },
                    { extend: 'csv', text: 'Export CSV' },
                    { extend: 'excel', text: 'Export Excel' },
                    { extend: 'pdf', text: 'Export PDF' },
                    { extend: 'print', text: 'Print' },
                    { extend: 'colvis', text: 'Colvis' }
                ],
                pagingType: 'full_numbers',
                pageLength: 10,
                lengthMenu: [10, 25, 50, 100],
                language: {
                    paginate: {
                        first: "<?php echo e(__('First')); ?>",
                        previous: "<?php echo e(__('Previous')); ?>",
                        next: "<?php echo e(__('Next')); ?>",
                        last: "<?php echo e(__('Last')); ?>",
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Zisan\Projects\JPFashionPOS\JPFashionPos\resources\views/admin/customerPayments/show.blade.php ENDPATH**/ ?>