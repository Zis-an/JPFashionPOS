<?php $__env->startSection('title', 'Admins'); ?>
<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1>Admins</h1>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admins.create')): ?>
                <a href="<?php echo e(route('admin.admins.create')); ?>" class="btn btn-primary mt-2">Add new</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admins.trashed')): ?>
                <a href="<?php echo e(route('admin.admins.trashed')); ?>" class="btn btn-danger mt-2">Trash List</a>
            <?php endif; ?>

        </div>
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                <li class="breadcrumb-item active">Admins</li>
            </ol>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admins.list')): ?>
                <div class="card">
                    <div class="card-body table-responsive">
                        <table id="adminsList" class="table  dataTable table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Photo</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Roles</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <img class="rounded border" width="100px" src="<?php echo e(getAssetUrl($admin->photo,$admin->name)); ?>" alt="<?php echo e($admin->name); ?>">
                                    </td>
                                    <td><?php echo e($admin->name ?? ''); ?></td>
                                    <td><?php echo e($admin->email ?? ''); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $admin->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a class="badge badge-success text-capitalize"><?php echo e($role->name); ?></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td class="text-capitalize"><?php echo e(($admin->type == 'salesman' ? 'Salesman' : 'Not a Salesman') ?? ''); ?></td>
                                    <td>
                                        <?php if($admin->status=='active'): ?> <span class="badge-success badge">Active</span>
                                        <?php else: ?> <span class="badge-danger badge">Deactivate</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <form action="<?php echo e(route('admin.admins.destroy', $admin->id)); ?>" method="POST">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admins.view')): ?>
                                                <a href="<?php echo e(route('admin.admins.show',['admin'=>$admin->id])); ?>" class="btn btn-info px-1 py-0 btn-sm"><i class="fa fa-eye"></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admins.update')): ?>
                                                <a href="<?php echo e(route('admin.admins.edit',['admin'=>$admin->id])); ?>" class="btn btn-warning px-1 py-0 btn-sm"><i class="fa fa-pen"></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admins.delete')): ?>
                                                <button onclick="isDelete(this)" class="btn btn-danger btn-sm px-1 py-0"><i class="fa fa-trash"></i></button>
                                            <?php endif; ?>

                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                            <tfoot>
                            <tr>
                                <th>Photo</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Roles</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <strong>Developed by <a href="https://www.techyfo.com">Techyfo</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>version</b> <?php echo e(env('DEV_VERSION')); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('plugins.datatablesPlugins', true); ?>
<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>


<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>
        function isDelete(button) {
            event.preventDefault();
            var row = $(button).closest("tr");
            var form = $(button).closest("form");
            Swal.fire({
                title: <?php echo json_encode(__('Delete Admin'), 15, 512) ?>,
                text: <?php echo json_encode(__('Are you sure you want to delete this?'), 15, 512) ?>,
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: <?php echo json_encode(__('Delete'), 15, 512) ?>,
                cancelButtonText: <?php echo json_encode(__('Cancel'), 15, 512) ?>,
            }).then((result) => {
                console.log(result)
                if (result.value) {
                    // Trigger the form submission
                    form.submit();
                }
            });
        }

        $(document).ready(function() {
            $("#adminsList").DataTable({
                dom: 'Bfrtip',
                responsive: true,
                lengthChange: false,
                autoWidth: false,
                searching: true,
                ordering: true,
                info: true,
                paging: true,
                buttons: [
                    {
                        extend: 'copy',
                        text: 'Copy',
                    },
                    {
                        extend: 'csv',
                        text: 'Export CSV',
                    },
                    {
                        extend: 'excel',
                        text: 'Export Excel',
                    },
                    {
                        extend: 'pdf',
                        text: 'Export PDF',
                    },
                    {
                        extend: 'print',
                        text: 'Print',
                    },
                    {
                        extend: 'colvis',
                        text: 'Colvis',
                    }
                ],
                pagingType: 'full_numbers',
                pageLength: 10,
                lengthMenu: [10, 25, 50, 100],
                language: {
                    paginate: {
                        first: "<?php echo e(__('First')); ?>",
                        previous: "<?php echo e(__('Previous')); ?>",
                        next: "<?php echo e(__('Next')); ?>",
                        last: "<?php echo e(__('Last')); ?>",
                    }
                }
            });

        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Zisan\Projects\JPFashionPOS\JPFashionPos\resources\views/admin/admins/index.blade.php ENDPATH**/ ?>