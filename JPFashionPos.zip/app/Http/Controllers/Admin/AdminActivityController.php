<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Traits\AdminLog;
use Illuminate\Http\Request;


class AdminActivityController extends Controller
{
    use AdminLog;
}
